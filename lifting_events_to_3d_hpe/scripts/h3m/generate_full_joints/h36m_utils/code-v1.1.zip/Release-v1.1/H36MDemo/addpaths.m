addpath('../H36M');
addpath('../H36MBL');
addpath('../H36MGUI');
addpath(genpath('../utils'));
addpath(genpath('../external_utils'));

if exist('../mine/','dir')
	addpath(genpath('../mine/'));
end

if exist('../iccv13/','dir')
  addpath(genpath('../iccv13/'));
end