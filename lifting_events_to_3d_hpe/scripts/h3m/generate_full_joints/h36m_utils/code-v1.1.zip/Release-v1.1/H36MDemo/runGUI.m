addpaths;
clear all;
H36MGui;
