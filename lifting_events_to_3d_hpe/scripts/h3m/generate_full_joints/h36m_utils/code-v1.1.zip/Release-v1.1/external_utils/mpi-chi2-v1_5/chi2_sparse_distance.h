#include <mex.h>

void chi2_sparse_distance(mwIndex *ir, mwIndex *jc, double *nums, int npoints, mwIndex *ir2, mwIndex *jc2, double *nums2, int npoints2, double *dist);
