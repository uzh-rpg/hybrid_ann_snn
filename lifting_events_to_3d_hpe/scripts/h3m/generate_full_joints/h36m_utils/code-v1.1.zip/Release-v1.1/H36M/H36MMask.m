classdef DB4MPMask
  properties
  end
  
  methods
  end
end