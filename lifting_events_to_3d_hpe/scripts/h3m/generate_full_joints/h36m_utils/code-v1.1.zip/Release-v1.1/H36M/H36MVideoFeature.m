classdef H36MVideoFeature < H36MFeature
  % FIXME bring here all the code for resize
end